export interface User {
  id: string;
  name: string;
  role: 'admin' | 'student';
  symbolNo?: string;
}

export interface TestResult {
  id: string;
  symbolNo: string;
  candidateName: string;
  reading: number | null;
  listening: number | null;
  writing: number | null;
  speaking: number | null;
  overallBand: number | null;
  testDate: string;
  status: 'draft' | 'published';
  comments: string;
  uploadedBy: string;
  uploadedAt: string;
}

export interface UpcomingTest {
  id: string;
  name: string;
  date: string;
  time: string;
  registeredStudents: number;
  type: 'IELTS' | 'NEET' | 'JEE' | 'Engineering';
}

export interface Activity {
  id: string;
  type: 'result_published' | 'batch_upload' | 'report_download' | 'result_verified';
  description: string;
  timestamp: string;
  user: string;
}

export interface Statistics {
  totalStudents: number;
  studentGrowth: number;
  testsCompleted: number;
  testGrowth: number;
  resultsDownloaded: number;
  downloadGrowth: number;
  successRate: number;
  successGrowth: number;
}