import React, { useState, useEffect } from 'react';
import { User, LogOut, Menu, X } from 'lucide-react';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import StudentDashboard from './components/StudentDashboard';
import PublicResults from './components/PublicResults';
import { User as UserType } from './types';

function App() {
  const [user, setUser] = useState<UserType | null>(null);
  const [currentView, setCurrentView] = useState<'login' | 'admin' | 'student' | 'public'>('login');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem('oli_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      setCurrentView(parsedUser.role === 'admin' ? 'admin' : 'student');
    }
  }, []);

  const handleLogin = (userData: UserType) => {
    setUser(userData);
    localStorage.setItem('oli_user', JSON.stringify(userData));
    setCurrentView(userData.role === 'admin' ? 'admin' : 'student');
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('oli_user');
    setCurrentView('login');
    setMobileMenuOpen(false);
  };

  const renderView = () => {
    switch (currentView) {
      case 'login':
        return <Login onLogin={handleLogin} />;
      case 'admin':
        return <AdminDashboard user={user} />;
      case 'student':
        return <StudentDashboard user={user} />;
      case 'public':
        return <PublicResults />;
      default:
        return <Login onLogin={handleLogin} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-blue-700">Oli & Associates</h1>
                <p className="text-xs text-gray-600">Mock Test Result Portal</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <button
                onClick={() => setCurrentView('public')}
                className="text-gray-700 hover:text-blue-700 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Public Results
              </button>
              {!user ? (
                <button
                  onClick={() => setCurrentView('login')}
                  className="bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-800 transition-colors"
                >
                  Login
                </button>
              ) : (
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <User className="h-5 w-5 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">{user.name}</span>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                      {user.role}
                    </span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="flex items-center space-x-1 text-gray-700 hover:text-red-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </nav>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-gray-700 hover:text-blue-700 p-2"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <button
                onClick={() => {
                  setCurrentView('public');
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 text-base font-medium text-gray-700 hover:text-blue-700 hover:bg-gray-50"
              >
                Public Results
              </button>
              {!user ? (
                <button
                  onClick={() => {
                    setCurrentView('login');
                    setMobileMenuOpen(false);
                  }}
                  className="block w-full text-left px-3 py-2 text-base font-medium text-blue-700 hover:bg-blue-50"
                >
                  Login
                </button>
              ) : (
                <div className="space-y-1">
                  <div className="px-3 py-2 text-sm text-gray-600">
                    Logged in as: <span className="font-medium">{user.name}</span>
                    <span className="ml-2 text-xs bg-gray-100 px-2 py-1 rounded">{user.role}</span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-3 py-2 text-base font-medium text-red-600 hover:bg-red-50"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderView()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Oli & Associates</h3>
              <p className="text-gray-300">
                Professional Mock Test Result Portal for IELTS and competitive exam preparation.
              </p>
            </div>
            <div>
              <h4 className="text-md font-semibold mb-4">Contact Support</h4>
              <div className="space-y-2">
                <a
                  href="mailto:ict@technologist.com"
                  className="block text-gray-300 hover:text-white transition-colors"
                >
                  📩 ict@technologist.com
                </a>
                <a
                  href="mailto:connect@technologist.com"
                  className="block text-gray-300 hover:text-white transition-colors"
                >
                  📩 connect@technologist.com
                </a>
              </div>
            </div>
            <div>
              <h4 className="text-md font-semibold mb-4">Notice</h4>
              <p className="text-gray-300 text-sm">
                Only results published by Oli & Associates will appear in the public results section.
              </p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Oli & Associates. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;