import React, { useState, useEffect } from 'react';
import { 
  Users, 
  FileText, 
  Download, 
  TrendingUp, 
  Calendar,
  Clock,
  Activity,
  Plus,
  Search,
  Filter,
  Upload
} from 'lucide-react';
import { User, TestResult, UpcomingTest, Activity as ActivityType, Statistics } from '../types';
import StatCard from './StatCard';
import ResultsTable from './ResultsTable';
import UpcomingTestsCard from './UpcomingTestsCard';
import RecentActivityCard from './RecentActivityCard';
import DateTimeDisplay from './DateTimeDisplay';

interface AdminDashboardProps {
  user: User | null;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ user }) => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'draft' | 'published'>('all');
  const [loading, setLoading] = useState(true);

  // Mock data
  const statistics: Statistics = {
    totalStudents: 247,
    studentGrowth: 18,
    testsCompleted: 523,
    testGrowth: 25,
    resultsDownloaded: 1923,
    downloadGrowth: 32,
    successRate: 95,
    successGrowth: 5
  };

  const upcomingTests: UpcomingTest[] = [
    {
      id: '1',
      name: 'NEET Mock Test – Series 15',
      date: '2025-03-20',
      time: '10:00 AM',
      registeredStudents: 1250,
      type: 'NEET'
    },
    {
      id: '2',
      name: 'JEE Main Practice Test',
      date: '2025-03-22',
      time: '2:00 PM',
      registeredStudents: 980,
      type: 'JEE'
    },
    {
      id: '3',
      name: 'Engineering Entrance Mock',
      date: '2025-03-25',
      time: '9:00 AM',
      registeredStudents: 750,
      type: 'Engineering'
    },
    {
      id: '4',
      name: 'IELTS Weekly Mock Test',
      date: '2025-03-28',
      time: '7:00 AM – 10:00 AM',
      registeredStudents: 425,
      type: 'IELTS'
    }
  ];

  const recentActivities: ActivityType[] = [
    {
      id: '1',
      type: 'result_published',
      description: 'IELTS Mock Test Series – Results Published',
      timestamp: '2 hours ago',
      user: 'Admin'
    },
    {
      id: '2',
      type: 'batch_upload',
      description: 'IELTS Practice Test – Batch Upload Complete',
      timestamp: '4 hours ago',
      user: 'Admin'
    },
    {
      id: '3',
      type: 'report_download',
      description: 'Performance Analytics Report Downloaded',
      timestamp: '6 hours ago',
      user: 'Admin'
    },
    {
      id: '4',
      type: 'result_verified',
      description: 'IELTS Mock Test – Results Verified',
      timestamp: '1 day ago',
      user: 'Admin'
    }
  ];

  useEffect(() => {
    // Mock data for results
    const mockResults: TestResult[] = [
      {
        id: '1',
        symbolNo: '24070101',
        candidateName: 'Arjun Shah',
        reading: 6.5,
        listening: 5.5,
        writing: 6.5,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'published',
        comments: 'Missing Speaking & Overall',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      },
      {
        id: '2',
        symbolNo: '24070102',
        candidateName: 'Juna Bhandari',
        reading: 6,
        listening: 4.5,
        writing: null,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'published',
        comments: 'Missing Writing, Speaking, Overall',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      },
      {
        id: '3',
        symbolNo: '24070103',
        candidateName: 'Sonishma Dulal',
        reading: 5.5,
        listening: 5.5,
        writing: 6,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'published',
        comments: 'Missing Speaking & Overall',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      },
      {
        id: '4',
        symbolNo: '24070104',
        candidateName: 'Mohit Mahato',
        reading: 5,
        listening: 5.5,
        writing: 6,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'draft',
        comments: 'Missing Speaking & Overall',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      },
      {
        id: '5',
        symbolNo: '24070105',
        candidateName: 'Kushal Karki Doli',
        reading: 4.5,
        listening: null,
        writing: null,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'draft',
        comments: 'No paper submitted',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      }
    ];

    setResults(mockResults);
    setLoading(false);
  }, []);

  const filteredResults = results.filter(result => {
    const matchesSearch = result.candidateName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         result.symbolNo.includes(searchTerm);
    const matchesStatus = statusFilter === 'all' || result.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="mt-2 text-sm text-gray-600">
            Welcome back, {user?.name}. Here's what's happening with your tests today.
          </p>
        </div>
        <div className="mt-4 lg:mt-0 flex items-center space-x-4">
          <DateTimeDisplay />
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            <Plus className="h-4 w-4 mr-2" />
            Add Result
          </button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Students"
          value={statistics.totalStudents}
          change={statistics.studentGrowth}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="IELTS Tests Conducted"
          value={statistics.testsCompleted}
          change={statistics.testGrowth}
          icon={FileText}
          color="green"
        />
        <StatCard
          title="Results Downloaded"
          value={statistics.resultsDownloaded}
          change={statistics.downloadGrowth}
          icon={Download}
          color="purple"
        />
        <StatCard
          title="Success Rate"
          value={`${statistics.successRate}%`}
          change={statistics.successGrowth}
          icon={TrendingUp}
          color="orange"
        />
      </div>

      {/* Upcoming Tests and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <UpcomingTestsCard tests={upcomingTests} />
        <RecentActivityCard activities={recentActivities} />
      </div>

      {/* Results Management */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                Test Results Management
              </h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">
                Manage and publish IELTS test results
              </p>
            </div>
            <div className="mt-4 sm:mt-0 flex space-x-3">
              <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <Upload className="h-4 w-4 mr-2" />
                Bulk Upload
              </button>
              <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <Download className="h-4 w-4 mr-2" />
                Export
              </button>
            </div>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="flex-1 min-w-0">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search by name or symbol number..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as 'all' | 'draft' | 'published')}
                className="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-md"
              >
                <option value="all">All Status</option>
                <option value="draft">Draft</option>
                <option value="published">Published</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results Table */}
        <ResultsTable results={filteredResults} isAdmin={true} />
      </div>
    </div>
  );
};

export default AdminDashboard;