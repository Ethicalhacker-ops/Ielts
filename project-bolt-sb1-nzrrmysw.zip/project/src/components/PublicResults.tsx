import React, { useState, useEffect } from 'react';
import { Search, Download, FileText, AlertCircle } from 'lucide-react';
import { TestResult } from '../types';
import ResultsTable from './ResultsTable';
import DateTimeDisplay from './DateTimeDisplay';

const PublicResults: React.FC = () => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock published results only
    const mockResults: TestResult[] = [
      {
        id: '1',
        symbolNo: '24070101',
        candidateName: 'Arjun Shah',
        reading: 6.5,
        listening: 5.5,
        writing: 6.5,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'published',
        comments: 'Missing Speaking & Overall',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      },
      {
        id: '2',
        symbolNo: '24070102',
        candidateName: 'Juna Bhandari',
        reading: 6,
        listening: 4.5,
        writing: null,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'published',
        comments: 'Missing Writing, Speaking, Overall',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      },
      {
        id: '3',
        symbolNo: '24070103',
        candidateName: 'Sonishma Dulal',
        reading: 5.5,
        listening: 5.5,
        writing: 6,
        speaking: null,
        overallBand: null,
        testDate: '2024-07-01',
        status: 'published',
        comments: 'Missing Speaking & Overall',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      }
    ];

    setResults(mockResults.filter(result => result.status === 'published'));
    setLoading(false);
  }, []);

  const filteredResults = results.filter(result => {
    const matchesSearch = result.candidateName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         result.symbolNo.includes(searchTerm);
    return matchesSearch;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900">Public Results</h1>
        <p className="mt-2 text-sm text-gray-600">
          Search and view published IELTS test results
        </p>
        <DateTimeDisplay />
      </div>

      {/* Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start">
          <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div className="ml-3">
            <p className="text-sm text-blue-800">
              <strong>Notice:</strong> Only results published by Oli & Associates will appear here. 
              If you cannot find your result, please contact our support team.
            </p>
          </div>
        </div>
      </div>

      {/* Search Section */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Search Results
          </h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Enter candidate name or symbol number to search for results
          </p>
        </div>
        <div className="px-4 py-5 sm:px-6">
          <div className="max-w-lg">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search by candidate name or symbol number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                Published Results
              </h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">
                {filteredResults.length} result(s) found
              </p>
            </div>
            {filteredResults.length > 0 && (
              <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </button>
            )}
          </div>
        </div>

        {filteredResults.length === 0 ? (
          <div className="px-4 py-12 text-center">
            <FileText className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No results found</h3>
            <p className="mt-1 text-sm text-gray-500">
              {searchTerm ? 'Try adjusting your search terms.' : 'No published results available at this time.'}
            </p>
          </div>
        ) : (
          <ResultsTable results={filteredResults} isAdmin={false} />
        )}
      </div>
    </div>
  );
};

export default PublicResults;