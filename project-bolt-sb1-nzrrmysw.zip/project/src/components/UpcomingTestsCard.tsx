import React from 'react';
import { Calendar, Clock, Users } from 'lucide-react';
import { UpcomingTest } from '../types';

interface UpcomingTestsCardProps {
  tests: UpcomingTest[];
}

const UpcomingTestsCard: React.FC<UpcomingTestsCardProps> = ({ tests }) => {
  const getTestTypeColor = (type: string) => {
    switch (type) {
      case 'IELTS':
        return 'bg-blue-100 text-blue-800';
      case 'NEET':
        return 'bg-green-100 text-green-800';
      case 'JEE':
        return 'bg-purple-100 text-purple-800';
      case 'Engineering':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <h3 className="text-lg leading-6 font-medium text-gray-900">
          Upcoming Tests
        </h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">
          Scheduled mock tests and examinations
        </p>
      </div>
      <div className="px-4 py-5 sm:px-6">
        <div className="space-y-4">
          {tests.map((test) => (
            <div key={test.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <div className="flex items-center space-x-3">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getTestTypeColor(test.type)}`}>
                    {test.type}
                  </span>
                  <h4 className="text-sm font-medium text-gray-900">{test.name}</h4>
                </div>
                <div className="mt-2 flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>{formatDate(test.date)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{test.time}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{test.registeredStudents} students</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UpcomingTestsCard;