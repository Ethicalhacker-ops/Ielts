import React, { useState, useEffect } from 'react';
import { FileText, Download, Calendar, Clock, TrendingUp, Award } from 'lucide-react';
import { User, TestResult } from '../types';
import ResultsTable from './ResultsTable';
import DateTimeDisplay from './DateTimeDisplay';

interface StudentDashboardProps {
  user: User | null;
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user }) => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock student results
    const mockResults: TestResult[] = [
      {
        id: '1',
        symbolNo: user?.symbolNo || '24070101',
        candidateName: user?.name || 'Student',
        reading: 6.5,
        listening: 5.5,
        writing: 6.5,
        speaking: 6.0,
        overallBand: 6.0,
        testDate: '2024-07-01',
        status: 'published',
        comments: 'Good performance. Focus on listening skills.',
        uploadedBy: 'admin',
        uploadedAt: '2024-07-05'
      },
      {
        id: '2',
        symbolNo: user?.symbolNo || '24070101',
        candidateName: user?.name || 'Student',
        reading: 6.0,
        listening: 6.0,
        writing: 6.5,
        speaking: 6.5,
        overallBand: 6.5,
        testDate: '2024-06-15',
        status: 'published',
        comments: 'Improved performance. Keep practicing.',
        uploadedBy: 'admin',
        uploadedAt: '2024-06-20'
      }
    ];

    setResults(mockResults);
    setLoading(false);
  }, [user]);

  const latestResult = results[0];
  const averageScore = results.reduce((sum, result) => sum + (result.overallBand || 0), 0) / results.length;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Student Dashboard</h1>
          <p className="mt-2 text-sm text-gray-600">
            Welcome back, {user?.name}. Track your IELTS test progress here.
          </p>
        </div>
        <DateTimeDisplay />
      </div>

      {/* Student Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Tests Taken
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {results.length}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Award className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Latest Score
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {latestResult?.overallBand || 'N/A'}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Average Score
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {averageScore.toFixed(1)}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calendar className="h-6 w-6 text-orange-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Last Test
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {latestResult ? new Date(latestResult.testDate).toLocaleDateString() : 'N/A'}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Score Progress Chart */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Score Progress
          </h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Track your IELTS band score improvements over time
          </p>
        </div>
        <div className="px-4 py-5 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {latestResult && (
              <>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{latestResult.reading || 'N/A'}</div>
                  <div className="text-sm text-gray-500">Reading</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{latestResult.listening || 'N/A'}</div>
                  <div className="text-sm text-gray-500">Listening</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{latestResult.writing || 'N/A'}</div>
                  <div className="text-sm text-gray-500">Writing</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{latestResult.speaking || 'N/A'}</div>
                  <div className="text-sm text-gray-500">Speaking</div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Results History */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                Your Test Results
              </h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">
                Complete history of your IELTS test performances
              </p>
            </div>
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
              <Download className="h-4 w-4 mr-2" />
              Download All
            </button>
          </div>
        </div>
        <ResultsTable results={results} isAdmin={false} />
      </div>
    </div>
  );
};

export default StudentDashboard;