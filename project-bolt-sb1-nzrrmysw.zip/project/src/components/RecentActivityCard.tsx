import React from 'react';
import { Activity, FileText, Upload, Download, CheckCircle } from 'lucide-react';
import { Activity as ActivityType } from '../types';

interface RecentActivityCardProps {
  activities: ActivityType[];
}

const RecentActivityCard: React.FC<RecentActivityCardProps> = ({ activities }) => {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'result_published':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'batch_upload':
        return <Upload className="h-5 w-5 text-blue-600" />;
      case 'report_download':
        return <Download className="h-5 w-5 text-purple-600" />;
      case 'result_verified':
        return <FileText className="h-5 w-5 text-orange-600" />;
      default:
        return <Activity className="h-5 w-5 text-gray-600" />;
    }
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <h3 className="text-lg leading-6 font-medium text-gray-900">
          Recent Activity
        </h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">
          Latest IELTS-related activities and updates
        </p>
      </div>
      <div className="px-4 py-5 sm:px-6">
        <div className="flow-root">
          <ul className="-mb-8">
            {activities.map((activity, index) => (
              <li key={activity.id}>
                <div className="relative pb-8">
                  {index !== activities.length - 1 && (
                    <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200" />
                  )}
                  <div className="relative flex items-start space-x-3">
                    <div className="relative">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100">
                        {getActivityIcon(activity.type)}
                      </div>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div>
                        <div className="text-sm">
                          <p className="font-medium text-gray-900">{activity.description}</p>
                        </div>
                        <p className="mt-0.5 text-sm text-gray-500">
                          {activity.timestamp} • by {activity.user}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default RecentActivityCard;